//
// Created by Jason Herrera on 9/28/20.
//
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <filesystem>
#include <cstdio>
#include <unistd.h>
#include <vector>
#include <memory.h>
// #include <stdlib.h>

extern "C" {
    #include "crypto-algorithms/sha256.h"
	#include "crypto-algorithms/aes.h"
}

#include "crypto-algorithms/sha256.h"

using namespace std;
namespace fs = std::__fs::filesystem;

const char* ARCFILE = "arc";

const int n_sha = 10000; // Number of iterations for the SHA function to encrypt

const BYTE KEYHASH[SHA256_BLOCK_SIZE] = {0xf9,0x61,0xd2,0x93,0x8b,0xa0,0x87,0xe0,0xa4,0xd9,0xe0,0x09,0xc6,0x27,0x18,0xc1,
										 0x40,0x9f,0xa1,0x1f,0x44,0x53,0x5e,0x72,0x0c,0x91,0xd7,0x70,0xf0,0x75,0x40,0x86};

// A function to prompt appropriate usage
void printUsage() {
    fprintf(stdout, "Usage: \n");
    fprintf(stdout, "cstore list archivename\n");
    fprintf(stdout, "cstore add [-p password] archivename file\n");
    fprintf(stdout, "cstore extract [-p password] archivename file\n");
    fprintf(stdout, "cstore delete [-p password] archivename file\n");
}

struct arcMeta {
	BYTE hmac_key[SHA256_BLOCK_SIZE];
	BYTE enc_key[SHA256_BLOCK_SIZE]; // This will be the true encrypt/ decrypt key (Not XORed)
	vector<string> fileNames;
};

// utility function to print bytes as hex:
void printHex (BYTE* ba, int len) {
	for(int i = 0; i < len; i++) {
		printf("%02X", ba[i]);
		if ((i % 4) == 3) {
             printf(" ");
		}
	}
	printf("\n");
}

/* Function to extract data from a metaFile */
arcMeta extractMetaData(string archiveName) {
	arcMeta data;
	BYTE hashed_encrypt_key[SHA256_BLOCK_SIZE];
	ifstream arcFS(archiveName + "/" + ARCFILE, ios_base::binary);
	arcFS.read((char*) data.hmac_key, SHA256_BLOCK_SIZE);
	arcFS.read((char*) hashed_encrypt_key, SHA256_BLOCK_SIZE);

	string fileName;
	while (getline(arcFS, fileName)) {
		data.fileNames.push_back(fileName);
	}
	arcFS.close();

	// restore true encryption key
	for (int i = 0; i < SHA256_BLOCK_SIZE; i++) {
		data.enc_key[i] = hashed_encrypt_key[i]^KEYHASH[i];
	}
	return data;
}

/* Write metadata to metadata file */
void writeMetaData(string archiveName, arcMeta data) {
	// create hashed encryption key to store in file
	BYTE hashed_encrypt_key[SHA256_BLOCK_SIZE];
	for (int i = 0; i < SHA256_BLOCK_SIZE; i++){
		hashed_encrypt_key[i] = data.enc_key[i]^KEYHASH[i];
	}

	ofstream arcFS(archiveName + "/" + ARCFILE, ifstream::binary);
	arcFS.write((char *) data.hmac_key, SHA256_BLOCK_SIZE);
	arcFS.write((char *) hashed_encrypt_key, SHA256_BLOCK_SIZE);
	for(auto& fileName : data.fileNames) {
		arcFS << fileName << endl;
	}
	arcFS.close();
}

void listArchive(char* archiveName) {
	arcMeta data = extractMetaData(archiveName);
	for(auto& fileName : data.fileNames) {
		cout << fileName.c_str() << endl;
	}
}

void sha256_repeat(string text, BYTE* outputBuf, int n) { // TODO: Loop SHA256 10000x
	BYTE bText[text.size()];
	strcpy((char *) bText, text.c_str());
	SHA256_CTX ctx;
	sha256_init(&ctx);
	sha256_update(&ctx, bText, strlen((char*) bText));
	sha256_final(&ctx, outputBuf);
}

void addFile(string archiveName, string fileName, string password) {
    // Create Encryption key from password
	BYTE key[SHA256_BLOCK_SIZE];
    sha256_repeat(password, key, n_sha);

    // If an archive does not exist, create the archive
	const fs::path path = archiveName;
	const string arcFilePath = archiveName + "/" + ARCFILE;
	if(fs::is_directory(path) && !fs::exists(arcFilePath)) {
		cout << "Failed to add file " << fileName << ":" << archiveName << " is not an archive." << endl;
		exit(1);
	} else if (!fs::is_directory(path)) {
		fs::create_directory(path);
		arcMeta data;
		memcpy(data.enc_key, key, SHA256_BLOCK_SIZE);
		memcpy(data.hmac_key, key, SHA256_BLOCK_SIZE); // placeholder
		writeMetaData(archiveName, data);
		cout << "Created new archive: " << archiveName << endl;
	}

	// Verify password; exit if incorrect password
	arcMeta data = extractMetaData(archiveName);
	if (memcmp(key, data.enc_key, SHA256_BLOCK_SIZE) != 0) {
		cout << "Access Denied: " << endl;
		exit(1);
	}

	// TODO: Check if file is already there

	// Read, Encrypt, Write file
	BYTE iBuf[16];
	BYTE oBuf[16];
	ifstream rawFS;
	ofstream encryptedFS;
	rawFS.open(fileName.c_str(), ifstream::binary);
	encryptedFS.open(archiveName + "/" + fileName.c_str() + ".arc", ifstream::binary);
	WORD key_schedule[60];
	aes_key_setup(key, key_schedule, 128);
	while(rawFS) {
		rawFS.read((char *) iBuf, 16);
		aes_encrypt( iBuf, oBuf, key_schedule, 128);
		encryptedFS.write((char *) oBuf, 16);
	}
	rawFS.close();
	encryptedFS.close();

	// TODO: Check archive integrity; return error if it fails

	// Update metafile to include new file list
	memcpy(data.hmac_key, key, SHA256_BLOCK_SIZE); // TODO: shoud be HMAC key
	data.fileNames.push_back(fileName);
	writeMetaData(archiveName, data);

	// Print message for User
	cout << "Encrypted " << fileName << endl;
    return;
}

void extractFile(string archiveName, string fileName, string password) {
	//Create decryption key based on password for extract command
	BYTE passedKey[SHA256_BLOCK_SIZE];
	sha256_repeat(password, passedKey, n_sha);

	// Retrieved data from Archive meta file
	arcMeta mData = extractMetaData(archiveName);

	// Verify password -> Exit if fails
	for(int i = 0; i < SHA256_BLOCK_SIZE; i++ ) {
		if(passedKey[i] != mData.enc_key[i] ) {
			cout << "Access Denied: " << archiveName << endl;
			exit(1);
		}
	}

    // Check that file exists in archive
    string fullFileName = archiveName + "/" + fileName + ".arc";
    if (!fs::exists(fullFileName) || fs::is_directory(fullFileName)) {
    	cout << fileName << " is not a valid file in archive" << archiveName << endl;
	}

    // TODO: Integrity check

    // Open encrypted file as ifstream, Open decrypted file for writing, and decrypt
	ifstream encryptedFS;
	ofstream decryptedFS;
    encryptedFS.open(archiveName + "/" + fileName.c_str() + ".arc", ifstream::binary);
    decryptedFS.open(fileName.c_str(), ifstream::binary);
	BYTE iBuf[16];
	BYTE oBuf[16];
	WORD key_schedule[60];
	aes_key_setup(passedKey, key_schedule, 128);
	while(encryptedFS) {
		encryptedFS.read((char *) iBuf, 16);
		aes_decrypt(iBuf, oBuf, key_schedule, 128);
		decryptedFS.write((char *) oBuf, 16);
	}
	encryptedFS.close();
	decryptedFS.close();

    // If successful, print message to User
	cout << "Decrypted " << fileName << endl;
	return;
}

void deleteFile(string archiveName, string fileName, string password) {
	//Create decryption key based on password for extract command
	BYTE passedKey[SHA256_BLOCK_SIZE];
	sha256_repeat(password, passedKey, n_sha);

	arcMeta mData = extractMetaData(archiveName);

	// Verify password -> Exit if fails
	for(int i = 0; i < SHA256_BLOCK_SIZE; i++ ) {
		if(passedKey[i] != mData.enc_key[i] ) {
			cout << "Access Denied: " << archiveName << endl;
			exit(1);
		}
	}

	// TODO: Integrity check

	// Remove file (Assume File is there)
	remove((archiveName + "/" + fileName.c_str() + ".arc").c_str());

	// Remove filename from list in Archive meta file
	int i;
	for(i = 0; i < mData.fileNames.size(); i++) {
		if(mData.fileNames[i] == fileName) {
			break;
		}
	}
	if(i >= mData.fileNames.size()) { // Error: File wasn't in List
		cout << "No such file in Archive" << archiveName << endl;
		exit(1);
	}
	mData.fileNames.erase(mData.fileNames.begin()+i); // Remove filename from

	// TODO: Update HMAC in Archive meta file

	// Write updated meta
	writeMetaData(archiveName, mData);

    // Print statement to User
    cout << "Removed: " << fileName << " from " << archiveName << endl;

    return;
}

int main(int argc, char **argv) {
    if(argc < 3) {
        printUsage();
        exit(1);
    }

    string cmd =argv[1];

    // handle 'cstore list archivename'
    if(argc==3 && cmd =="list") {
        listArchive(argv[2]);
        return 0;
    }

    // make sure it's one of the other commands
    if (cmd != "add" && cmd != "extract" && cmd != "delete") {
        printUsage();
        exit(1);
    }

    string password;
    string archiveName;
    int fileIndex;

    if (strcmp(argv[2], "-p") == 0 && argc > 5) {
        password = argv[3];
        archiveName = argv[4];
        fileIndex = 5;
    } else if (argc > 3){
        password = getpass("Enter password: ");
        archiveName = argv[2];
        fileIndex = 3;
    } else {
        printUsage();
        exit(1);
    }

    if(cmd == "add") {
        addFile(archiveName, argv[fileIndex], password);
    } else if(cmd == "extract") {
        extractFile(archiveName, argv[fileIndex], password);
    } else if(cmd == "delete") {
        deleteFile(archiveName, argv[fileIndex], password);
    }

    return 0;
}

