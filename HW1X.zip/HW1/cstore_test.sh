#!/bin/bash

# Compile cstore program
make all

# Create a raw file to be encrypted
touch sample1.txt
echo "Hello world, this is my test file: sample1." >> sample1.txt
echo "Most security problems are due to bugs in ordinary application code. This means that application programmers need some security background. This class is designed for all computer science majors. Topics covered included the basics of applied cryptography, memory safety, firewalls and other network security techniques, sandboxing, and access control." >> sample1.txt
echo "End of File sample1.txt" >> sample1.txt
cat sample1.txt
echo "TEST: Add file to new archive ..."
./cstore add -p password SampleArchive sample1.txt
echo "____________________________________________"

# Create another test file and add to same archive
touch sample2.txt
echo "This is the second file. " >> sample2.txt
echo "File sample2.txt"
cat sample2.txt
echo "TEST: Add file to archive ..."
./cstore add -p password SampleArchive sample2.txt
echo "____________________________________________"

# List archive
echo "List the archive files ..."
./cstore list SampleArchive
echo "____________________________________________"

# Remove sample files from archive
rm sample1.txt
rm sample2.txt

# extract the first file and second file
echo "TEST: Extract the files ..."
./cstore extract -p password SampleArchive sample1.txt
echo "FILE sample1.txt: "
cat sample1.txt
./cstore extract -p password SampleArchive sample2.txt
echo "FILE sample1.txt: "
cat sample2.txt
echo "____________________________________________"

# Delete
echo "TEST: Delete the files ..."
./cstore delete -p password SampleArchive sample1.txt
echo "FILE sample1.txt: "
cat sample1.txt
./cstore delete -p password SampleArchive sample2.txt
echo "FILE sample1.txt: "
cat sample2.txt
echo "____________________________________________"

# List archive
echo "List the archive files ..."
./cstore list SampleArchive
echo "____________________________________________"

# Cleanup
rm sample1.txt
rm sample2.txt
rm -r SampleArchive

